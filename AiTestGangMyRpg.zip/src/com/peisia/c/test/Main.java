package com.peisia.c.test;

import java.util.ArrayList;

import com.peisia.c.util.So;
import com.peisia.game.util.Dice;

/* 내 강화 학습 rpg. dev by sm.ahn */
/*
방에 쥐와 용이 있음.

쥐를 공격하면 쥐가 죽고 레벨이 1개 오름

용은 레벨이 100이 넘어야 공격 했을 때 용이 죽음

그전에 공격하면 플레이어가 죽고 게임 끝

용이 죽으면 게임 끝

진 엔딩은 가장 낮은 레벨로 공략했을때 나오게 함.

이 가장 낮은 공략 레벨을 찾아내는 문제임

단, 도전 횟수를 1회부터 ~ n 회까지 식으로 하지 않음. (이러면 너무 쉬움. 나중에 다른 영향 요인이 많아지게 개발하는 것을 감안한 기본 모델임 )

대략 1~200(지정값) 까지 수 중 랜덤 횟수 만큼 쥐를 잡게 하고

패배 레벨과
승리 레벨을 근거로
다시 랜덤 범위를 조정하는 식으로 처리함

마지막 결과도 최근 5번의 결과 레벨이 동일 할 경우에 끝내도록 함.

한 끝 차 조심
 */
public class Main {
	
	static final int ROLL = 200; 
	static final int SCORE_BASE = 100; 
	static ArrayList<Integer> winners = new ArrayList<>();
	
	public static void main(String[] args) {
		int regression = 1;
		int maxDieLevel = 1;
		int minWinLevel = ROLL;
		
		Player p = new Player("엠피스",1);
		Monster rat = new Rat("쥐",1);
		Monster dragon = new Dragon("용",100);
		
		
		while(true) {
			int r = Dice.aToB(maxDieLevel, minWinLevel-2);
			for(int i=0;i<r;i++) {
				rat.attack(p);
			}
			if(dragon.attack(p)) {
				So.ln(String.format("용사 %s 는 %s 를 물리치고 세계에 평화를 가져왔습니다. 끝. 마지막 레벨은 %d. %d 회차. 진엔딩은 아직..",p.name , dragon.name, p.level, regression));
				//승리 처리
				winners.add(p.level);
				
				//진엔딩 판단
				if(ginEnding()) {
					So.ln(String.format("용사 %s 는 %s 를 물리치고 진짜로 세계에 평화를 가져왔습니다. 끝. 마지막 레벨은 %d. %d 회차. 진엔딩 끝",p.name , dragon.name, p.level, regression));
					break;
				}
				minWinLevel = p.level;
				p.level = 1;
				regression++;	//다음 회귀 값 +
			} else {
				So.ln(String.format("유다희. 마지막 레벨은 %d",p.level));
				if(maxDieLevel < p.level) {
					maxDieLevel = p.level;
				}
				p.level = 1;
			}
			
		}
	}
	
	public static boolean ginEnding() {
		int ws = winners.size();
		if(ws>=5) {
			int w1 = winners.get(ws-1);
			int w2 = winners.get(ws-2);
			int w3 = winners.get(ws-3);
			int w4 = winners.get(ws-4);
			int w5 = winners.get(ws-5);
			if(w1 == w2 && w2 == w3 && w3 == w4 && w4 == w5) {
				return true;
			}
		}
		return false;
	}
}
