package com.peisia.c.test;

public class Monster {
	String name;
	int winLevel;
	public Monster(String name, int winLevel) {
		this.name = name;
		this.winLevel = winLevel;
	}
	
	public boolean attack(Player p) {
		if(p.level >= winLevel) {
			p.levelUp();	//렙업함
			return true;
		} else {
			return false;
		}
	}
}
