package com.peisia.c.util;

public class Disp {
	static public void mainTitle(String title, String version, String author) {
		line();
		dot(10);
		space(10);
		So.p(String.format("%s %s %s", title, version, author));
		space(10);
		dot(10);
		So.ln();
		line();
	}

	// final 키워드를 붙이면 변수가 상수가 됨. 처음에 값이 들어가면 이후 값을 못 바꿈.
	// 상수 명명 국룰 = 이름을 다 대문자로 씀.
	// static 변수:Disp.DOT 식으로 객체 생성없이 아무데서 사용 가능.
	// > 같은 식구 ex. line() 들은 그냥 DOT 이라고 쓸 수 있음.
	final static String DOT = "★";
	final static int DOT_COUNT = 48;

	public static void line() { // static 함수:Disp.line() 식으로 객체 생성없이 아무데서 사용 가능.
		for (int i = 0; i < DOT_COUNT; i = i + 1) {
			So.p(DOT); // static 멤버 변수는 사용 가능.
		}
		So.ln();
	}

//	public static void title() {
//		line();
//		dot(10);
//		So.w(" 고양이 카페 (v."+Kiosk.VERSION+" by sm.ahn) ");
//		dot(10);
//		So.ln();
//		line();
//	}

	public static void dot(int n) {
		for (int i = 0; i < n; i++) {
			So.p(DOT);
		}
	}
	
	public static void space(int n) {
		for (int i = 0; i < n; i++) {
			So.p(" ");
		}
	}

	public static void clearScreen() {
		for (int i = 0; i < 80; i++) {
			System.out.println("");
		}
	}
}
