package com.peisia.c.test;

public class Dragon extends Monster {
	public Dragon(String name, int winLevel) {
		super(name, winLevel);
	}
	
	public boolean attack(Player p) {
		if(p.level >= winLevel) {
//			p.levelUp();	//렙업 안하게
			return true;
		} else {
			return false;
		}
	}	
}
