package com.peisia.c.test;

public class Player {
	String name;
	int level = 0;
	public Player(String name, int level) {
		this.name = name;
		this.level = level;
	}
	public Player(String name) {
		this.name = name;
	}
	public void levelUp() {
		level++;
	}
}