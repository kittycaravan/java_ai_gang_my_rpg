package com.peisia.c.test;

public class Rat extends Monster {
	public Rat(String name, int winLevel) {
		super(name, winLevel);
	}
}
