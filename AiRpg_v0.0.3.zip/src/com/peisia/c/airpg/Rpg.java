package com.peisia.c.airpg;

import com.peisia.c.airpg.data.Data;
import com.peisia.c.airpg.menu.MenuMain;
import com.peisia.c.util.Disp;

public class Rpg {
	static public Data data = new Data();
	public void run() {
		Disp.title();
		new MenuMain().run();
	}
}