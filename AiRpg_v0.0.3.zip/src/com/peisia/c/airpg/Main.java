package com.peisia.c.airpg;

/* 내 강화 학습 rpg. dev by sm.ahn */
public class Main {
	static public String VERSION = "v0.0.3";
	static public String AUTHOR = "sm.ahn";
	static public String PROGRAME_TITLE = "AiRpg";
	static public String TITLE = String.format("%s <%s %s>", PROGRAME_TITLE, VERSION, AUTHOR);
	
	public static void main(String[] args) {
		Rpg rpg = new Rpg();
		rpg.run();
	}
}
