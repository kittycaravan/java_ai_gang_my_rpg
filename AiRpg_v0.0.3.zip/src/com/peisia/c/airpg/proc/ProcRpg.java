package com.peisia.c.airpg.proc;

import com.peisia.c.airpg.Rpg;
import com.peisia.c.airpg.menu.MenuGame;
import com.peisia.c.util.Ci;

public class ProcRpg {
	
	public void run() {
		////케릭터, 길드 생성
		Rpg.data.pName = Ci.r("케릭터 이름을 입력해주세요:");
		Rpg.data.gName = Ci.r("길드 이름을 입력해주세요:");
		////데이터 초기화
		Rpg.data.gGold = 100;
		Rpg.data.turn = 0;
		
		////프롤로그
//		new ProcPrologue().run();
		
		////시작
		new MenuGame().run();
	}
}