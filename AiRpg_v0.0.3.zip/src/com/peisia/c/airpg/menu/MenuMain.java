package com.peisia.c.airpg.menu;

import java.sql.SQLException;

import com.peisia.c.airpg.Rpg;
import com.peisia.c.airpg.db.Db;
import com.peisia.c.airpg.proc.ProcRpg;
import com.peisia.c.airpg.proc.ProcRpgTest;
import com.peisia.c.util.Ci;
import com.peisia.c.util.So;

public class MenuMain {
	public void run() {
		main: while (true) {
			switch(Ci.r("[1.새게임 / 2.save / 3.load / 99.test / e. 종료]:")) {
			case "1":
				ProcRpg pr = new ProcRpg();
				pr.run();
				break;
			case "2":
				save();
				break;
			case "3":
				load();
				new MenuGame().run();
				break;
			case "99":
				ProcRpgTest prt = new ProcRpgTest();
				prt.run();
				break;
			case "e":
				So.ln("프로그램 종료");
				break main;
			default:
				So.ln("장난x");
				break;
			}
		}
	}
	
	void save() {
		Db db = new Db();
		String p = Rpg.data.pName;
		String g = Rpg.data.gName;
		long gold = Rpg.data.gGold;
		long turn = Rpg.data.turn;
		String sql = String.format("update %s set a_name='%s', a_guild_name='%s', a_gold=%d, a_turn=%d", "ai_rpg_data", p, g, gold, turn);
		db.dbUpdate(sql);
	}
	void load() {
		Db db = new Db();
		String sql = String.format("select * from %s", "ai_rpg_data");
		db.dbQuery(sql);
		try {
			db.r.next();
			Rpg.data.pName = db.r.getString("a_name");
			Rpg.data.gName = db.r.getString("a_guild_name");
			Rpg.data.gGold = db.r.getLong("a_gold");
			Rpg.data.turn  = db.r.getLong("a_turn");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		db.close();
	}
}
