package com.peisia.c.util;

public class Sleep {
	static public void sec(int sec) {
        try {
        	Thread.sleep(sec*1000);
        } catch (InterruptedException e) {
        	e.printStackTrace();
        }
	}
}
