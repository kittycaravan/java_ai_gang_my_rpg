package com.peisia.game.util;

public class Dice {
	static public int roll(int n) {
		return (int)(Math.random()*n+1);
	}
	static public int aToB(int a,int b) {
		return (int)(Math.random()*(b-a+1)+a);
	}
//	분자(molecular) - numerator
//	분모(denominator) - denominator
	static public boolean dropRate(int numerator, int denominator) {
		int r = (int)(Math.random()*denominator+1);
		System.out.println(String.format("%d / %d 확률에서 %d 가나옴", numerator, denominator, r));
		if(r <= numerator) {
			return true;
		}
		return false;
	}
}
