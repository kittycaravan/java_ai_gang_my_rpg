package com.peisia.c.airpg.data;

import com.peisia.c.util.So;

public class Data {
	public String pName; 
	public String gName; 
	public long gGold; 
	public long turn;
	public void info() {
		String s = String.format("[💰:%d][턴:%d]",gGold,turn);
		So.ln(s);
	}
	public void turn() {
		turn++;
	}
	public void gold(int g) {
		gGold+=g;
	}
}
