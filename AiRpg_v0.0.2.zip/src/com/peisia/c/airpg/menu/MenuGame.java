package com.peisia.c.airpg.menu;

import com.peisia.c.airpg.Rpg;
import com.peisia.c.airpg.proc.guild.ProcGuild;
import com.peisia.c.airpg.proc.person.ProcPerson;
import com.peisia.c.util.Ci;
import com.peisia.c.util.So;

public class MenuGame {
	public void run() {
		main: while (true) {
			Rpg.data.info();
			switch(Ci.r("[1.행동 길드 / 2.행동 개인 / e. 메인으로]:")) {
			case "1":
				new ProcGuild().run();
				break;
			case "2":
				new ProcPerson().run();
				break;
			case "e":
				break main;
			default:
				So.ln("장난x");
				break;
			}
		}
	}
}
