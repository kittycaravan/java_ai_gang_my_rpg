package com.peisia.c.airpg.menu;

import com.peisia.c.airpg.proc.ProcRpg;
import com.peisia.c.airpg.proc.ProcRpgTest;
import com.peisia.c.util.Ci;
import com.peisia.c.util.So;

public class MenuMain {
	public void run() {
		main: while (true) {
			switch(Ci.r("[1.새게임 / 99.test / e. 종료]:")) {
			case "1":
				ProcRpg pr = new ProcRpg();
				pr.run();
				break;
			case "99":
				ProcRpgTest prt = new ProcRpgTest();
				prt.run();
				break;
			case "e":
				So.ln("프로그램 종료");
				break main;
			default:
				So.ln("장난x");
				break;
			}
		}
	}
}
