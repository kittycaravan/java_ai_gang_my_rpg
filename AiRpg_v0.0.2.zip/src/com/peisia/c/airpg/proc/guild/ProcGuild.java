package com.peisia.c.airpg.proc.guild;

import com.peisia.c.airpg.Rpg;
import com.peisia.c.util.Ci;
import com.peisia.c.util.So;

public class ProcGuild {
	public void run() {
		So.ln("길드 행동");
		loop: while (true) {
			Rpg.data.info();
			switch(Ci.r("[1.직원 / 2.파견 / 9.길드 사무소 / 0.턴진행 / x. 이전]:")) {
			case "1":
				new ProcEmployee().run();
				break;
			case "2":
				new ProcDispatch().run();
				break;
			case "9":
				new ProcOffice().run();
				break;
			case "0":
				Rpg.data.turn();
				break;
			case "x":
				break loop;
			default:
				So.ln("장난x");
				break;
			}
		}		
	}
}
