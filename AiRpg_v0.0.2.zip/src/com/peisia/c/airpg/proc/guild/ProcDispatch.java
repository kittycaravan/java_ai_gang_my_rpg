package com.peisia.c.airpg.proc.guild;

import com.peisia.c.airpg.Rpg;
import com.peisia.c.util.Ci;
import com.peisia.c.util.So;

public class ProcDispatch {
	public void run() {
		loop: while (true) {
			switch(Ci.r("[1.사냥터 보내기 / x. 이전]:")) {
			case "1":
				So.ln("10골드를 벌었다.");
				Rpg.data.gold(10);
				Rpg.data.turn();
				break loop;
			case "2":
				break;
			case "x":
				break loop;
			default:
				So.ln("장난x");
				break;
			}
		}		
	}
}
