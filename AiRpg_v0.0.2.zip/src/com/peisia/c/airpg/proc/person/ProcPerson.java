package com.peisia.c.airpg.proc.person;

import com.peisia.c.util.So;

public class ProcPerson {
	public void run() {
		So.ln("개인 행동");
	}
}
