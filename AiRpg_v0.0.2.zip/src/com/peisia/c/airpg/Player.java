package com.peisia.c.airpg;

public class Player {
	public String name;
	public int level = 0;
	public Player(String name, int level) {
		this.name = name;
		this.level = level;
	}
	public Player(String name) {
		this.name = name;
	}
	public void levelUp() {
		level++;
	}
}