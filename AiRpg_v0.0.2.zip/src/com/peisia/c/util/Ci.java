
package com.peisia.c.util;

import java.util.Scanner;

public class Ci {
	static private Scanner sc = new Scanner(System.in);
	public static String r() {
		return sc.nextLine();
	}
	public static String r(String g) {
		So.p(g);
		return sc.nextLine();
	}
	public static int ri(String g) {
		So.p(g);
		int n = 0;
		try {
			n = Integer.parseInt(g);
		} catch(Exception e) {
			n = 0;
		}
		return n;
	}
}
