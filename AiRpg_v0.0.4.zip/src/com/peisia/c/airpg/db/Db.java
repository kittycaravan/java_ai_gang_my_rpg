package com.peisia.c.airpg.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.peisia.c.util.So;

public class Db {
	
	
	private Connection c;
	public java.sql.Statement s;
	public ResultSet r;
	
	public void connect() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("잘연결됨");
			//																		   *db명*   *id*     *암호*				
			c = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			s = c.createStatement();	// Statement는 정적 SQL문을 실행하고 결과를 반환받기 위한 객체. Statement하나당 한개의 ResultSet 객체만을 열 수있다.			
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e) {	// java try-catch 문. p.14장 참고. 일단 그냥 복붙.
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	public void close() {
		if(r!=null) {
			try {
				r.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(s!=null) {
			try {
				s.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(c!=null) {
			try {
				c.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	//todo select 은 직접 처리하기
	public void dbQuery(String q) {
		So.ln(q);
		connect();
		try {
			r = s.executeQuery(q);
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	public int dbUpdate(String q) {
		So.ln(q);
		connect();
		int n = 0;
		try {
			n = s.executeUpdate(q);
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
		close();
		return n;
	}
}
