package com.peisia.c.airpg.data;

import com.peisia.c.util.So;

public class Data {
	public String pName; 
	public String gName; 
	public long gGold; 
	public long turn;
	public int pHp;
	public int pMaxHp;
//	public int pLevel;
	public void info() {
		String s = String.format("[턴:%d][🩸%d/%d][💰:%d]",turn,pHp,pMaxHp,gGold);
		So.ln(s);
	}
	public void turn() {
		turn++;
	}
	public void gold(int g) {
		gGold+=g;
		So.ln(g+" 골드");
	}
	public void hp(int n) {
		pHp+=n;
		if(pHp > pMaxHp) {
			pHp = pMaxHp;
		}
		So.ln(n+" hp");
	}
	public void save() {
		
	}
	public void load() {
		
	}
}
