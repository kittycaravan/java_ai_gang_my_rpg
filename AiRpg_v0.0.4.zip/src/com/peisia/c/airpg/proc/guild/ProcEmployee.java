package com.peisia.c.airpg.proc.guild;

import com.peisia.c.util.Ci;
import com.peisia.c.util.So;

public class ProcEmployee {
	public void run() {
		loop: while (true) {
			switch(Ci.r("[1.리스트 / 2. / x. 이전]:")) {
			case "1":
				break;
			case "2":
				break;
			case "x":
				break loop;
			default:
				So.ln("장난x");
				break;
			}
		}		
	}
}
