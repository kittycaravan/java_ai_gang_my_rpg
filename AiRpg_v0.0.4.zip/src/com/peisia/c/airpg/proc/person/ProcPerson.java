package com.peisia.c.airpg.proc.person;

import com.peisia.c.airpg.Rpg;
import com.peisia.c.util.Ci;
import com.peisia.c.util.Sleep;
import com.peisia.c.util.So;
import com.peisia.game.util.Dice;

public class ProcPerson {
	public void run() {
		loop: while (true) {
			Rpg.data.info();
			switch(Ci.r("[1.사냥터 다녀오기 / 2.휴식 / 3.병원 / 4.훈련 / x. 이전]:")) {
			case "1":
//				Sleep.sec(1);
				Rpg.data.gold(Dice.aToB(-2, 10));
				Rpg.data.turn();
				Rpg.data.hp(Dice.aToB(-10,-1));
				break;
			case "2":
				Rpg.data.hp(Dice.aToB(5,10));
				Rpg.data.turn();
				break;
			case "3":
				Rpg.data.gold(-10);
				Rpg.data.hp(Dice.aToB(50,100));
				Rpg.data.turn();
				break;
			case "x":
				break loop;
			default:
				So.ln("장난x");
				break;
			}
		}	
	}
}
