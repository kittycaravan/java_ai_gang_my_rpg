package com.peisia.c.airpg.proc;

import java.util.ArrayList;

import com.peisia.c.airpg.Dragon;
import com.peisia.c.airpg.Monster;
import com.peisia.c.airpg.Player;
import com.peisia.c.airpg.Rat;
import com.peisia.c.util.So;
import com.peisia.game.util.Dice;

public class ProcRpgTest {
	final int ROLL = 200; 
	final int SCORE_BASE = 100; 
	ArrayList<Integer> winners = new ArrayList<>();
	
	public void run() {
		int regression = 1;	//회귀 수.
		int maxDieLevel = 1;
		int minWinLevel = ROLL;
		
		Player p = new Player("엠피스",1);
		Monster rat = new Rat("쥐",1);
		Monster dragon = new Dragon("용",100);
		
		while(true) {
			int r = Dice.aToB(maxDieLevel, minWinLevel-2);
			for(int i=0;i<r;i++) {
				rat.attack(p);
			}
			if(dragon.attack(p)) {
				So.ln(String.format("[회차 %3d] 용사 %s 는 %s 를 물리치고 세계에 평화를 가져왔습니다. 끝. 마지막 레벨은 %d. 진엔딩은 아직..",regression, p.name , dragon.name, p.level));
				//승리 처리
				winners.add(p.level);
				
				//진엔딩 판단
				if(ginEnding()) {
					So.ln(String.format("[회차 %3d] 용사 %s 는 %s 를 물리치고 진짜로 세계에 평화를 가져왔습니다. 끝. 마지막 레벨은 %d. 진엔딩 끝",regression, p.name , dragon.name, p.level));
					break;
				}
				minWinLevel = p.level;
				p.level = 1;
			} else {
				So.ln(String.format("[회차 %3d] 유다희. 마지막 레벨은 %d.",regression,p.level));
				if(maxDieLevel < p.level) {
					maxDieLevel = p.level;
				}
				p.level = 1;
			}
			regression++;	//다음 회귀 값 +
		}
	}
	
	public boolean ginEnding() {
		int ws = winners.size();
		if(ws>=5) {
			int w1 = winners.get(ws-1);
			int w2 = winners.get(ws-2);
			int w3 = winners.get(ws-3);
			int w4 = winners.get(ws-4);
			int w5 = winners.get(ws-5);
			if(w1 == w2 && w2 == w3 && w3 == w4 && w4 == w5) {
				return true;
			}
		}
		return false;
	}
}
