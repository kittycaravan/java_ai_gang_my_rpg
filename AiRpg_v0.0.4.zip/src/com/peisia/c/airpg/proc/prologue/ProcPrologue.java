package com.peisia.c.airpg.proc.prologue;

import com.peisia.c.util.Sleep;
import com.peisia.c.util.So;

public class ProcPrologue {
	int d = 1;
	public void run() {
		So.ln("...");
		Sleep.sec(d);
		So.ln("......");
		Sleep.sec(d);
		So.ln("당신은 심한 두통을 느끼며 잠에서 깨어난다.");
		Sleep.sec(d);
        So.ln("'아오.. 머리야..'");
        Sleep.sec(d);
        So.ln("머리를 감싸쥐며 몸을 일으켜 본다. 정신을 차리고 눈을 떠보니 낯선 풍경이 눈에 들어온다.");
        Sleep.sec(d);
        So.ln("\"이계에 잘 도착한건가?\"");
	}
}
